package br.com.contabank;

import java.util.Scanner;

public class Contabank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// instancia os objetos
		Scanner leia = new Scanner(System.in);
		Conta conta = new Conta("1001-1","10101-1", 0);
		
		// Declara��o de vari�veis
		int operacao;
		String msg;
		
		// Usu�rio informa os dados
		System.out.println("Informe o nome do titular:");
		conta.nomeTitular = leia.nextLine();
		System.out.println("Informe o CPF do titular:");
		conta.cpfTitular = leia.nextLine();
		System.out.println("Ag�ncia: " + conta.agencia);
		System.out.println("Conta:" + conta.numeroConta);
		
		do {
			System.out.println("Escolha a opera��o desejada:");
			System.out.println("1 - Consultar saldo");
			System.out.println("2 - Depositar dinheiro");
			System.out.println("3 - Sacar dinheiro");
			System.out.println("4 - Sair");
			operacao = leia.nextInt();
			
			switch (operacao) {
				case 1:
					System.out.println("Saldo: " + conta.consultarSaldo());
					break;
				case 2:
					System.out.println("Informe o valor do dep�sito:");
					msg = conta.depositarValor(leia.nextDouble());
					System.out.println(msg);
					break;
				case 3:
					System.out.println("Informe o valor do saque:");
					msg = conta.sacarValor(leia.nextDouble());
					System.out.println(msg);
					break;
				case 4:
					System.out.println("Tenha um �timo dia.");
					break;
				default:
					System.out.println("Opera��o inv�lida");
					break;
			}
			
		} while (operacao != 4);
	}

}
