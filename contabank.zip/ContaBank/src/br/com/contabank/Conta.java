package br.com.contabank;

public class Conta {
	// Atributos
	public String nomeTitular;
	public String cpfTitular;
	public String agencia;
	public String numeroConta;
	public double saldo;
	
	// M�todo construtor
	public Conta(String agencia, String numeroConta, double saldo) {
		// TODO Auto-generated constructor stub
		this.agencia = agencia;
		this.numeroConta = numeroConta;
		this.saldo = saldo;
	}
	
	// M�todos
	public double consultarSaldo() {
		return this.saldo;
	}
	
	public String depositarValor(double valor) {
		this.saldo = this.saldo + valor;
		return "Valor depositado com sucesso!";
	}

	public String sacarValor(double valor) {
		if (this.saldo >= valor) {
			this.saldo = this.saldo - valor;
			return "Saque efetuado com sucesso";
		}
		else
			return "Saldo insuficiente";
	}
}
